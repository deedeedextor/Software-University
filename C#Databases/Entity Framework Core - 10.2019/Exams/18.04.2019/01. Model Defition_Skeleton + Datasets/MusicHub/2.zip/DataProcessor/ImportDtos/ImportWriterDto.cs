﻿using System.ComponentModel.DataAnnotations;

namespace MusicHub.DataProcessor.ImportDtos
{
    public class ImportWriterDto
    {
        public string Name { get; set; }

        public string Pseudonym { get; set; }
    }
}
