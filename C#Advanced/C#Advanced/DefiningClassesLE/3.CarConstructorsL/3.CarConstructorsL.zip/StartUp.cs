﻿using System;
using System.Collections.Generic;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());

            Car firstCar = new Car();
            Car secondCar = new Car(make, model, year);
            Car thirdcar = new Car(make, model, year, fuelQuantity, fuelConsumption);

            List<Car> Cars = new List<Car>();

            Cars.Add(firstCar);
            Cars.Add(secondCar);
            Cars.Add(thirdcar);

            foreach (var car in Cars)
            {
                Console.WriteLine($"{car.Make}\n{car.Model}\n{car.Year}\n{car.FuelQuantity}\n{car.FuelConsumption}");
            }
        }
    }
}
