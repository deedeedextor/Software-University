﻿namespace BorderConstrol
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Pet : LivingCreature
    {
        public Pet(string name, string birthdate) 
            : base(name, birthdate)
        {
        }
    }
}
