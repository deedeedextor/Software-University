﻿namespace BorderConstrol
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Program
    {
        static void Main(string[] args)
        {
            List<IBirthable> creatures = new List<IBirthable>();

            string input = string.Empty;

            while ((input = Console.ReadLine().Trim()) != "End")
            {
                var creatureTokens = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string typeOfCreature = creatureTokens[0];

                switch (typeOfCreature)
                {
                    case "Citizen":
                        string name = creatureTokens[1];
                        int age = int.Parse(creatureTokens[2]);
                        string id = creatureTokens[3];
                        string birthdate = creatureTokens[4];

                        creatures.Add(new Citizen(name, age, id, birthdate));
                        break;

                    case "Pet":
                        string petName = creatureTokens[1];
                        string petBirthdate = creatureTokens[2];

                        creatures.Add(new Pet(petName, petBirthdate));
                        break;

                    case "Robot":
                    default:
                        break;
                }
            }

            var yearToPrint = Console.ReadLine().Trim();

            var birthdateInYear = creatures
                .Where(c => c.Birthdate.EndsWith(yearToPrint))
                .Select(c => c.Birthdate);

            if (birthdateInYear != null)
            {
                Console.WriteLine(string.Join(Environment.NewLine, birthdateInYear));
            }
        }
    }
}
