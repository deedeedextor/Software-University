﻿namespace BorderConstrol
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Pet : LivingCreatures
    {
        public Pet(string name, string birthdate) 
            : base(name, birthdate)
        {
        }
    }
}
