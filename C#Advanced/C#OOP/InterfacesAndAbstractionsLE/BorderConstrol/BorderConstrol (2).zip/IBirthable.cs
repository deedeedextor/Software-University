﻿namespace BorderConstrol
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IBirthable
    {
        string Name { get; }

        string Birthdate { get; }
    }
}
