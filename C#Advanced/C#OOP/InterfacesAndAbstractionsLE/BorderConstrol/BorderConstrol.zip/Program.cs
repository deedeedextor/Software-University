﻿namespace BorderConstrol
{
    using System;
    using System.Collections.Generic;

    public class Program
    {
        static void Main(string[] args)
        {
            var passersBy = new HashSet<string>();

            string input = string.Empty;

            while ((input = Console.ReadLine().Trim()) != "End")
            {
                passersBy.Add(input);
            }

            var fakeIds = Console.ReadLine();

            foreach (var entity in passersBy)
            {
                if (entity.EndsWith(fakeIds))
                {
                    Console.WriteLine(entity.Substring(entity.LastIndexOf(" ") + 1));
                }
            }
        }
    }
}
