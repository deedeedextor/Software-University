﻿namespace Cars
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Seat : Car
    {
        public Seat(string model, string color) 
            : base(model, color)
        {
        }
    }
}
