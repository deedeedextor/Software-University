﻿namespace Vehicles
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Truck : Vehicle
    {
        private const double TakenFuelInCharging = 0.95;

        public Truck(double fuelQuantity, double fuelConsumption, double airConditioningConsumption, double tankCapacity) 
            : base(fuelQuantity, fuelConsumption, airConditioningConsumption, tankCapacity)
        {
        }

        public override void Refuel(double fuel)
        {
            fuel *= TakenFuelInCharging;
            base.Refuel(fuel);
        }
    }
}
