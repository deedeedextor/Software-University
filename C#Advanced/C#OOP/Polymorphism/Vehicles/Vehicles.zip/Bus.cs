﻿namespace Vehicles
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Bus : Vehicle
    {
        private bool isAirConditionerTurnedOn;

        public Bus(double fuelAmount, double fuelConsumption, double airConditioningConsumption, double tankCapacity)
            : base(fuelAmount, fuelConsumption, airConditioningConsumption, tankCapacity)
        {
            this.isAirConditionerTurnedOn = true;
        }

        public bool IsAirConditionerTurnedOn
        {
            get { return this.isAirConditionerTurnedOn; }
            set { this.isAirConditionerTurnedOn = value; }
        }

        public override string Drive(double distance)
        {
            if (this.isAirConditionerTurnedOn)
            {
                return base.Drive(distance);
            }

            var neededFuel = this.FuelConsumption * distance;

            if (neededFuel > this.FuelQuantity)
            {
                return $"Bus needs refueling";
            }

            this.FuelQuantity -= neededFuel;
            return $"Bus travelled {distance} km";
        }
    }
}
