﻿namespace Vehicles
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;
        private double airConditioningConsumption;
        //private double tankCapacity;

        public Vehicle(double fuelQuantity, double fuelConsumption, double airConditioningConsumption)//, double tankCapacity)
        {
            this.fuelQuantity = fuelQuantity;
            this.fuelConsumption = fuelConsumption;
            this.airConditioningConsumption = airConditioningConsumption;
            //this.tankCapacity = tankCapacity;
        }

        //protected virtual double FuelQuantity
        //{
        //    get
        //    {
        //        return this.fuelQuantity;
        //    }
        //
        //    set
        //    {
        //        this.ValidatePositiveFuel(value);
        //        
        //        this.fuelQuantity = value;
        //    }
        //}
        //
        //protected double TankCapacity
        //{
        //    get => this.tankCapacity;
        //    private set
        //    {
        //        if (value < this.fuelQuantity)
        //        {
        //            value = 0;
        //        }
        //
        //        this.tankCapacity = value;
        //    }
        //}

        //protected double FuelConsumption => this.fuelConsumption;

        public virtual void Refuel(double fuel)
        {
            //this.ValidatePositiveFuel(fuel);
            //
            //if (this.fuelQuantity + fuel > tankCapacity)
            //{
            //    throw new ArgumentException($"Cannot fit {fuel} fuel in the tank");
            //}
            //
            //else
            //{
            //    this.fuelQuantity += fuel;
            //}

            this.fuelQuantity += fuel;
        }

        public virtual string Drive(double distance)
        {
            var neededFuel = (fuelConsumption + airConditioningConsumption) * distance;

            if (neededFuel > this.fuelQuantity)
            {
                return $"{this.GetType().Name} needs refueling";
            }

            this.fuelQuantity -= neededFuel;

            return $"{this.GetType().Name} travelled {distance} km";
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.fuelQuantity:F2}";
        }

        //private void ValidatePositiveFuel(double value)
        //{
        //    if (value <= 0)
        //    {
        //        throw new ArgumentException("Fuel must be a positive number");
        //    }
        //}
    }
}
