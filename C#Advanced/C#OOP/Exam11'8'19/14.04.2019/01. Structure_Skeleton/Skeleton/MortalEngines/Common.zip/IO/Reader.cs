﻿using MortalEngines.IO.Contracts;

namespace MortalEngines.IO
{
    public class Reader : IReader
    {
        //public System.Collections.Generic.IList<ICommand> ReadCommands()
        //{
        //    throw new System.NotImplementedException();
        //}
    }
}
