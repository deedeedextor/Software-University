﻿using System;
using System.Collections.Generic;
using System.Text;
using MortalEngines.Entities.Contracts;

namespace MortalEngines.Entities.Models
{
    public abstract class BaseMachine : IMachine
    {
        private string name;
        private IPilot pilot;
        private readonly IList<string> targets;

        private BaseMachine()
        {
            Targets = new List<string>();
        }

        public BaseMachine(string name, double attackPoints, double defencePoints, double healthPoints)
            : this()
        {
            Name = name;
            AttackPoints = attackPoints;
            DefensePoints = defencePoints;
            HealthPoints = healthPoints;
        }

        public string Name
        {
            get
            {
                return name;
            }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Machine name cannot be null or empty.");
                }

                name = value;
            }

        }

        public IPilot Pilot
        {
            get
            {
                return pilot;
            }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException("Pilot cannot be null.");
                }

                pilot = value;
            }
        }
        public double HealthPoints { get; set; }

        public double AttackPoints { get; protected set; }

        public double DefensePoints { get; protected set; }

        public IList<string> Targets { get; private set; }

        public void Attack(IMachine target)
        {
            if (target == null)
            {
                throw new NullReferenceException("Target cannot be null");
            }

            double valueToDecrease = Math.Abs(AttackPoints - target.DefensePoints);

            if (target.HealthPoints - valueToDecrease < 0)
            {
                target.HealthPoints = 0;
            }
            else
            {
                target.HealthPoints -= valueToDecrease;
            }

            Targets.Add(target.Name);
        }

        public override string ToString()
        {
            var information = new StringBuilder();

            information.AppendLine($"- {Name}");
            information.AppendLine($" *Type: {GetType().Name}");
            information.AppendLine($" *Health: {HealthPoints:F2}");
            information.AppendLine($" *Attack: {AttackPoints:F2}");
            information.AppendLine($" *Defense: {DefensePoints:F2}");

            if (Targets.Count != 0)
            {
                information.AppendLine($" *Targets: {string.Join(",", targets)}");
            }

            else
            {
                information.AppendLine("None");
            }

            return information.ToString().TrimEnd();
        }
    }
}
