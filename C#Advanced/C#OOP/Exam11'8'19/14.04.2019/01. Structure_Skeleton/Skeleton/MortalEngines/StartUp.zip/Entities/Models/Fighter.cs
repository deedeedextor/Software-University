﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Entities.Models
{
    public class Fighter : BaseMachine, IFighter
    {
        private const double DefaultHealthPoints = 200;
        private const double AttackPointsIncrease = 50;
        private const double DefencePointsDecrease = 25;

        public Fighter(string name, double attackPoints, double defencePoints)
            : base(name, attackPoints + AttackPointsIncrease, defencePoints - DefencePointsDecrease, DefaultHealthPoints)
        {
            AggressiveMode = true;
        }

        public bool AggressiveMode { get; private set; }

        public void ToggleAggressiveMode()
        {
            if (AggressiveMode == false)
            {
                AggressiveMode = true;

                AttackPoints += AttackPointsIncrease;
                DefensePoints -= DefencePointsDecrease;
            }
            else
            {
                AggressiveMode = false;

                AttackPoints -= AttackPointsIncrease;
                DefensePoints += DefencePointsDecrease;
            }
        }

        public override string ToString()
        {
            string result = string.Empty;

            if (AggressiveMode == false)
            {
                result = base.ToString() + Environment.NewLine + " *Aggressive: OFF";
            }
            else
            {

                result = base.ToString() + Environment.NewLine + " *Aggressive: ON";
            }

            return result;
        }
    }
}
