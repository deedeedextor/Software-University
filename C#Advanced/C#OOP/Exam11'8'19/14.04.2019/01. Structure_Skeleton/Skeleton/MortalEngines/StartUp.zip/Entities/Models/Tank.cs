﻿using MortalEngines.Entities.Contracts;
using System;

namespace MortalEngines.Entities.Models
{
    public class Tank : BaseMachine, ITank
    {
        private const double InitialHealthPoints = 100;
        private const double AttackPointsDecrease = 40;
        private const double DefencePointsIncrease = 30;

        public Tank(string name, double attackPoints, double defencePoints) 
            : base(name, attackPoints - AttackPointsDecrease, defencePoints + DefencePointsIncrease, InitialHealthPoints)
        {
            this.DefenseMode = true;
        }

        public bool DefenseMode { get; private set; }

        public void ToggleDefenseMode()
        {
            if (this.DefenseMode == false)
            {
                this.DefenseMode = true;

                this.AttackPoints -= AttackPointsDecrease;
                this.DefensePoints += DefencePointsIncrease;
            }
            else
            {
                this.DefenseMode = false;

                this.AttackPoints += AttackPointsDecrease;
                this.DefensePoints -= DefencePointsIncrease;
            }
        }

        public override string ToString()
        {
            string result = string.Empty;

            if (this.DefenseMode == true)
            {
                result = base.ToString() + Environment.NewLine + " *Defense: ON";
            }
            else
            {
                result = base.ToString() + Environment.NewLine + " *Defense: OFF";
            }

            return result;
        }
    }
}
