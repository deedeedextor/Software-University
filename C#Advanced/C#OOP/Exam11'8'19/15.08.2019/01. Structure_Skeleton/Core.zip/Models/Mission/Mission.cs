﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Planets;
using SpaceStation.Repositories;
using SpaceStation.Repositories.Contracts;

namespace SpaceStation.Models.Mission
{
    public class Mission : IMission
    {
        IRepository<IAstronaut> astronautRepository = new AstronautRepository();

        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {
            while (true)
            {
                var astronaut = this.astronautRepository
                    .Models
                    .FirstOrDefault(a => a.CanBreath);

                if (astronaut == null)
                {
                    break;
                }

                astronaut.Breath();

                var item = planet.Items.First();

                astronaut.Bag.Items.Add(item);

                planet.Items.Remove(item);

                if (!astronaut.CanBreath)
                {
                    break;
                }
            }
        }
    }
}
